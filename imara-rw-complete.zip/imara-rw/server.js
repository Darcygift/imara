require('dotenv').config();
const express  = require('express');
const mongoose = require('mongoose');
const jwt      = require('jsonwebtoken');
const cors     = require('cors');
const path     = require('path');
const { User, Listing, Booking, Message } = require('./models');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'imara-rw-secret-2026';
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/imara-rw';

// ── MIDDLEWARE ────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── DB CONNECTION ─────────────────────────────────────────
mongoose.connect(MONGODB_URI)
  .then(() => { console.log('✅ MongoDB connected'); seedDemo(); })
  .catch(err => console.error('❌ MongoDB error:', err));

// ── AUTH MIDDLEWARE ───────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: 'Invalid token' }); }
}

// ── AUTH ROUTES ───────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, phone, role } = req.body;
    if (await User.findOne({ email })) return res.status(400).json({ error: 'Email already registered' });
    const user = await User.create({ name, email, password, phone, role: role || 'tenant' });
    const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password))) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role, phone: user.phone } });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/auth/me', auth, async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  res.json(user);
});

// ── LISTINGS ROUTES ───────────────────────────────────────
app.get('/api/listings', async (req, res) => {
  try {
    const { type, listing, district, minPrice, maxPrice, beds, verified, lat, lng, radius, search } = req.query;
    const filter = { available: true };
    if (type)     filter.type    = type;
    if (listing)  filter.listing = listing;
    if (district) filter.district = new RegExp(district, 'i');
    if (verified === 'true') filter.verified = true;
    if (beds)     filter.beds = { $gte: parseInt(beds) };
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = parseInt(minPrice);
      if (maxPrice) filter.price.$lte = parseInt(maxPrice);
    }
    if (search)   filter.$or = [
      { title: new RegExp(search, 'i') },
      { district: new RegExp(search, 'i') },
      { description: new RegExp(search, 'i') }
    ];
    const listings = await Listing.find(filter).populate('owner', 'name phone email').sort({ featured: -1, createdAt: -1 });
    res.json(listings);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/listings/:id', async (req, res) => {
  try {
    const listing = await Listing.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } }, { new: true }).populate('owner', 'name phone email avatar');
    if (!listing) return res.status(404).json({ error: 'Not found' });
    res.json(listing);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/listings', auth, async (req, res) => {
  try {
    const listing = await Listing.create({ ...req.body, owner: req.user.id });
    res.status(201).json(listing);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/listings/:id', auth, async (req, res) => {
  try {
    const listing = await Listing.findOneAndUpdate(
      { _id: req.params.id, owner: req.user.id },
      req.body, { new: true }
    );
    if (!listing) return res.status(404).json({ error: 'Not found or unauthorized' });
    res.json(listing);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/listings/:id', auth, async (req, res) => {
  try {
    await Listing.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    res.json({ success: true });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/my/listings', auth, async (req, res) => {
  const listings = await Listing.find({ owner: req.user.id }).sort({ createdAt: -1 });
  res.json(listings);
});

// ── BOOKINGS ROUTES ───────────────────────────────────────
app.post('/api/bookings', auth, async (req, res) => {
  try {
    const listing = await Listing.findById(req.body.listing);
    if (!listing) return res.status(404).json({ error: 'Listing not found' });
    const booking = await Booking.create({
      ...req.body, tenant: req.user.id, landlord: listing.owner,
      deposit: Math.round(listing.price * 0.1)
    });
    res.status(201).json(booking);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/my/bookings', auth, async (req, res) => {
  const bookings = await Booking.find({ tenant: req.user.id })
    .populate('listing', 'title district price type')
    .populate('landlord', 'name phone')
    .sort({ createdAt: -1 });
  res.json(bookings);
});

app.get('/api/landlord/bookings', auth, async (req, res) => {
  const bookings = await Booking.find({ landlord: req.user.id })
    .populate('listing', 'title district price')
    .populate('tenant', 'name phone email')
    .sort({ createdAt: -1 });
  res.json(bookings);
});

app.patch('/api/bookings/:id/status', auth, async (req, res) => {
  try {
    const booking = await Booking.findOneAndUpdate(
      { _id: req.params.id, landlord: req.user.id },
      { status: req.body.status }, { new: true }
    );
    res.json(booking);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// ── MESSAGES ROUTES ───────────────────────────────────────
app.post('/api/messages', auth, async (req, res) => {
  try {
    const msg = await Message.create({ ...req.body, from: req.user.id });
    res.status(201).json(msg);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/messages/:userId', auth, async (req, res) => {
  const msgs = await Message.find({
    $or: [
      { from: req.user.id, to: req.params.userId },
      { from: req.params.userId, to: req.user.id }
    ]
  }).sort({ createdAt: 1 });
  await Message.updateMany({ from: req.params.userId, to: req.user.id }, { read: true });
  res.json(msgs);
});

app.get('/api/messages', auth, async (req, res) => {
  const msgs = await Message.find({ $or: [{ from: req.user.id }, { to: req.user.id }] })
    .populate('from', 'name').populate('to', 'name').sort({ createdAt: -1 });
  res.json(msgs);
});

// ── STATS (admin/dashboard) ───────────────────────────────
app.get('/api/stats', auth, async (req, res) => {
  const [totalListings, totalUsers, totalBookings, myListings] = await Promise.all([
    Listing.countDocuments({ available: true }),
    User.countDocuments(),
    Booking.countDocuments(),
    Listing.countDocuments({ owner: req.user.id }),
  ]);
  res.json({ totalListings, totalUsers, totalBookings, myListings });
});

// ── SPA FALLBACK ──────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── DEMO SEED ─────────────────────────────────────────────
async function seedDemo() {
  const count = await Listing.countDocuments();
  if (count > 0) return;
  console.log('🌱 Seeding demo data...');
  let owner = await User.findOne({ email: 'demo@imara.rw' });
  if (!owner) {
    owner = await User.create({
      name: 'Imara Demo', email: 'demo@imara.rw',
      password: 'Demo1234!', role: 'landlord', phone: '+250788000000'
    });
  }
  const demos = [
    { title:'Luxury Apartment — Kiyovu', type:'apartment', listing:'rent', price:850000, beds:3, baths:2, sqm:120, district:'Kiyovu, Kigali', lat:-1.9500, lng:30.0619, verified:true, featured:true, description:'Modern 3-bedroom apartment in the heart of Kiyovu with panoramic city views, backup generator, and 24h security.', amenities:['WiFi','Security','Generator','Parking','Swimming Pool'] },
    { title:'Family Villa — Nyarutarama', type:'villa', listing:'sale', price:95000000, beds:5, baths:4, sqm:380, district:'Nyarutarama, Kigali', lat:-1.9438, lng:30.0916, verified:true, featured:true, description:'Spacious 5-bedroom villa in Nyarutarama with large garden, guest wing, and double garage.', amenities:['Garden','Garage','Security','Generator','WiFi','DSTV'] },
    { title:'Modern House — Kicukiro', type:'house', listing:'rent', price:420000, beds:4, baths:2, sqm:200, district:'Kicukiro, Kigali', lat:-1.9837, lng:30.0927, verified:true, description:'Bright 4-bedroom house with modern kitchen and large compound. Close to Kicukiro market.', amenities:['Parking','Security','WiFi'] },
    { title:'Studio Flat — Kimihurura', type:'studio', listing:'rent', price:280000, beds:1, baths:1, sqm:45, district:'Kimihurura, Kigali', lat:-1.9528, lng:30.0950, verified:false, description:'Cozy studio in Kimihurura, perfect for professionals. Fully furnished.', amenities:['Furnished','WiFi','Security'] },
    { title:'Commercial Space — CBD', type:'commercial', listing:'rent', price:1200000, beds:0, baths:2, sqm:300, district:'CBD, Kigali', lat:-1.9441, lng:30.0619, verified:true, description:'Prime commercial space in Kigali CBD. Ground floor, high footfall, suitable for retail or offices.', amenities:['Parking','Generator','WiFi','Security'] },
    { title:'Lake-View Home — Rubavu', type:'house', listing:'sale', price:65000000, beds:4, baths:3, sqm:250, district:'Rubavu', lat:-1.6815, lng:29.2588, verified:true, description:'Stunning lake-view property in Rubavu with views over Lake Kivu. Large terrace and garden.', amenities:['Lake View','Garden','Generator','WiFi'] },
    { title:'Penthouse — Gasabo', type:'apartment', listing:'sale', price:120000000, beds:4, baths:3, sqm:280, district:'Gasabo, Kigali', lat:-1.9145, lng:30.0960, verified:true, featured:true, description:'Top-floor penthouse with 360° views of Kigali. Premium finishes throughout.', amenities:['Rooftop','Gym','Swimming Pool','Security','Generator','Parking'] },
    { title:'Bungalow — Musanze', type:'house', listing:'rent', price:200000, beds:3, baths:1, sqm:130, district:'Musanze', lat:-1.4996, lng:29.6346, verified:false, description:'Peaceful bungalow near Volcanoes National Park. Ideal for tourism workers and families.', amenities:['Garden','Parking'] },
    { title:'Garden Villa — Kimironko', type:'villa', listing:'sale', price:78000000, beds:5, baths:3, sqm:320, district:'Kimironko, Kigali', lat:-1.9273, lng:30.1127, verified:true, description:'Large villa in Kimironko with private garden and staff quarters.', amenities:['Garden','Staff Quarter','Security','Generator','WiFi','Parking'] },
  ];
  await Listing.insertMany(demos.map(d => ({ ...d, owner: owner._id })));
  console.log('✅ Demo data seeded');
}

app.listen(PORT, () => console.log(`🚀 Imara.rw running on http://localhost:${PORT}`));
