const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// ── USER ──────────────────────────────────────────────────
const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  email:    { type: String, required: true, unique: true, lowercase: true },
  phone:    { type: String },
  password: { type: String, required: true },
  role:     { type: String, enum: ['tenant','landlord','agent','admin'], default: 'tenant' },
  avatar:   { type: String },
  verified: { type: Boolean, default: false },
  createdAt:{ type: Date, default: Date.now }
});
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});
userSchema.methods.comparePassword = function(plain) {
  return bcrypt.compare(plain, this.password);
};

// ── LISTING ───────────────────────────────────────────────
const listingSchema = new mongoose.Schema({
  title:       { type: String, required: true },
  description: { type: String },
  type:        { type: String, enum: ['apartment','house','villa','commercial','studio'], required: true },
  listing:     { type: String, enum: ['rent','sale','shortlet'], required: true },
  price:       { type: Number, required: true },
  currency:    { type: String, default: 'RWF' },
  period:      { type: String, enum: ['month','year','total'], default: 'month' },
  beds:        { type: Number, default: 0 },
  baths:       { type: Number, default: 0 },
  sqm:         { type: Number },
  amenities:   [String],
  images:      [String],
  district:    { type: String, required: true },
  address:     { type: String },
  lat:         { type: Number, required: true },
  lng:         { type: Number, required: true },
  upi:         { type: String },
  verified:    { type: Boolean, default: false },
  available:   { type: Boolean, default: true },
  featured:    { type: Boolean, default: false },
  owner:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  views:       { type: Number, default: 0 },
  createdAt:   { type: Date, default: Date.now }
});

// ── BOOKING ───────────────────────────────────────────────
const bookingSchema = new mongoose.Schema({
  listing:     { type: mongoose.Schema.Types.ObjectId, ref: 'Listing', required: true },
  tenant:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  landlord:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  visitDate:   { type: Date, required: true },
  status:      { type: String, enum: ['pending','confirmed','cancelled','completed'], default: 'pending' },
  payment:     { type: String, enum: ['momo','airtel','bank'], default: 'momo' },
  momoPhone:   { type: String },
  deposit:     { type: Number },
  escrowStatus:{ type: String, enum: ['pending','held','released','refunded'], default: 'pending' },
  notes:       { type: String },
  createdAt:   { type: Date, default: Date.now }
});

// ── MESSAGE ───────────────────────────────────────────────
const messageSchema = new mongoose.Schema({
  from:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  to:        { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  listing:   { type: mongoose.Schema.Types.ObjectId, ref: 'Listing' },
  text:      { type: String, required: true },
  read:      { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = {
  User:    mongoose.models.User    || mongoose.model('User',    userSchema),
  Listing: mongoose.models.Listing || mongoose.model('Listing', listingSchema),
  Booking: mongoose.models.Booking || mongoose.model('Booking', bookingSchema),
  Message: mongoose.models.Message || mongoose.model('Message', messageSchema),
};
